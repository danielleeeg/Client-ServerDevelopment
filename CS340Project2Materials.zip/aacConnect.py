# Example Python Code to Insert a Document
from pymongo import MongoClient
from bson.objectid import ObjectId


class AnimalShelter():
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password, host, port, database_name, collection_name):
        # Initializing the MongoClient. This helps to
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        # You must edit the connection variables below to reflect
        # your own instance of MongoDB!
        #
        # Connection Variables
        #
        USER = username
        PASS = password
        HOST = host
        PORT = port
        DB = database_name
        COL = collection_name
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER, PASS, HOST, PORT))
        
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]

    # Complete this create method to implement the C in CRUD.
    def create(self, data):

        # check that data is a dictionary
        if not isinstance(data, dict):
            raise ValueError("Invalid data format. Data must be a dictionary to be inserted into database")

        # use try exception to catch unexpected exceptions
        try:

            # insert data into database if it exists
            if data is not None:
                result = self.database.animals.insert_one(data)  # data should be dictionary

                # return true/false if successful
                return result.acknowledged

            # if data does not exist in squer, throw exception
            else:
                raise Exception("Nothing to save, because data parameter is empty")

        # catch and print exceptions
        except Exception as e:
            print("{exception_name}:{str(exception_description)}"
            .format(
                exception_name=type(e).__name__,
                exception_description=str(e))
            )

    # Create method to implement the R in CRUD.
    def read(self, query):

        # Input validation: check that query exists and is type dict
        if query is None or not isinstance(query, dict):
            raise TypeError("Invalid input; query must be a dictionary")

       
        # try finding items in database
        try:
            result = list(self.database.animals.find(query, {"_id":False}))

            # return empty list if no results found
            if not result:
                return [];

            # return list of results if results returned
            return result

        # catch and print exceptions
        except Exception as e:
            print("{exception_name}:{str(exception_description)}"
            .format(
                exception_name=type(e).__name__,
                exception_description=str(e))
            )
            
            
    # Update method to implement the U in CRUD.
    def update(self, query, data):
        try:
            # Input validation: check that query exists
            if query is None or not isinstance(query, dict):
                raise ValueError("Invalid input; query must be a dictionary")

            # Update the documents based on the filter
            result = self.database.animals.update_many(
                query,
                {"$set": data}
            )

            # Return the number of modified documents
            return result.modified_count

        # catch and print exceptions
        except Exception as e:
            print("{exception_name}:{str(exception_description)}"
            .format(
                exception_name=type(e).__name__,
                exception_description=str(e))
            )
            
    # Delete method to implement the D in CRUD.
    def delete(self, query):
        try:
            # Input validation: check that query exists
            if query is None or not isinstance(query, dict):
                raise ValueError("Invalid input; query must be provided as dictionary")

            # Delete the documents based on the filter
            result = self.database.animals.delete_many(query)

            # Return the number of deleted documents
            return result.deleted_count

        # catch and print exceptions
        except Exception as e:
            print("{exception_name}:{str(exception_description)}"
            .format(
                exception_name=type(e).__name__,
                exception_description=str(e))
            )
            

